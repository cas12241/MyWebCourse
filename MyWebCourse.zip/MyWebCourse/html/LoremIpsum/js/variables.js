let x = 10;
let y = '10';
let z = 30; 

console.log(`x is ${typeof x}`);
console.log(`y is ${typeof y}`);
console.log(`z is ${typeof z}`);
var newX = x++;
 
console.log("newX is " + newX);
console.log(x);
console.log("y is " + y);
console.log(y);
console.log("Does X equal to Y?  " + (x == y));
